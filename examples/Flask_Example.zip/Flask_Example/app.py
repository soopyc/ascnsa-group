from flask import Flask, render_template
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError
import os

ENV = os.environ.get('FLASK_ENV', 'development')  # Default to 'development'

app = Flask(__name__)

conn = 'mysql+pymysql://username:password@host/db_name'

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy
# Engines
conn_engine = create_engine(conn, echo=False)  # Read-only, but we won't write anyway

# Session makers
conn_session = sessionmaker(bind=conn_engine)

def init_db():
    with conn_engine.connect() as connection:
        try:
            # Determine ID definition based on database type
            if 'sqlite' in conn:
                id_def = 'INTEGER PRIMARY KEY'
            else:
                id_def = 'INT AUTO_INCREMENT PRIMARY KEY'

            # Create table if not exists
            create_sql = f"""
                CREATE TABLE IF NOT EXISTS customer (
                    id {id_def},
                    first_name VARCHAR(50) NOT NULL,
                    last_name VARCHAR(50) NOT NULL,
                    email VARCHAR(100) UNIQUE,
                    phone VARCHAR(20)
                )
            """
            connection.execute(text(create_sql))

            # Check if table is empty
            result = connection.execute(text("SELECT COUNT(*) FROM customer"))
            count = result.scalar()

            if count == 0:
                # Insert random data
                insert_sql = """
                    INSERT INTO customer (first_name, last_name, email, phone) VALUES
                    ('Bob', 'Smith', 'bob@example.com', '123-456-7890'),
                    ('Alice', 'Johnson', 'alice@example.com', '234-567-8901'),
                    ('Charlie', 'Brown', 'charlie@example.com', '345-678-9012'),
                    ('David', 'Wilson', 'david@example.com', '456-789-0123'),
                    ('Bob', 'Doe', 'bobdoe@example.com', '567-890-1234')
                """
                connection.execute(text(insert_sql))

            connection.commit()
        except SQLAlchemyError as e:
            print(f"Error initializing database: {e}")

@app.route('/')
def hello_world():  # put application's code here
    return render_template('index.html')
@app.route('/customers')
def customer_list():
    session = conn_session()
    try:
        result = session.execute(text("SELECT * FROM customer WHERE first_name = :name"), {'name': 'Bob'})
        customers = result.fetchall()
        return render_template('customer_list.html', customers=customers)
    except SQLAlchemyError as e:
        print(f"Error querying database: {e}")
        return []
    finally:
        session.close()


# Initialize the database
init_db()

if __name__ == '__main__':
    app.run()
